export type IProgressProps = {
  totalValue?: number
  currentValue?: number
  title?: string
}
