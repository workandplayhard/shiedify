import React from 'react'

export interface IConditionalWrapperProps {
  children: React.ReactNode
  Wrapper?: React.ElementType
  className?: string
}
