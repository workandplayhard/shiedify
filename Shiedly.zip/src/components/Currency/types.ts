export interface ICurrencyProps {
  value?: number
  currency?: string
  className?: string
}
