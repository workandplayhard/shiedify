export type IFormError = {
  error?: string
}
