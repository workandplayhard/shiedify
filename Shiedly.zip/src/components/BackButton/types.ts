export interface IBackButtonProps {
  label?: string
  disabled?: boolean
  onBack?: () => void
}
