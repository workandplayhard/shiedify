export interface IIconProps {
  name?: string
}
