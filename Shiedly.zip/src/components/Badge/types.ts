export type IBadgeProps = {
  children?: React.ReactNode
  type?: 'success' | 'warning' | 'error'
}
