export type IFormAlert = {
  children: React.ReactNode
}
