export interface ISwitchProps {
  active?: boolean
  className?: string
  onChange?: (_val: boolean) => void
}
