import { TypedTypePolicies } from './graphql/generated/apollo-helpers'

const typePolicies: TypedTypePolicies = {
  Query: {
    fields: {},
  },
}

export default typePolicies
