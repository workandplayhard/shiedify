export type OnBoardingStatus = 'initial' | 'preview'
