# React [Vite](https://vitejs.dev/guide/) Shieldify frontend

## Install packages

```bash
  $ yarn install
```

## Run

```bash
  $ yarn dev
```
The project will be available in `localhost:3000`